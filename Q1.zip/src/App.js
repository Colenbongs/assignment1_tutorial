import Details from './Components/details'
import Card from './Components/Card'
import './App.css';

function App() {
  return (
    <div className="App">
      <Details/>
      <Card/>
    </div>
  );
}

export default App;
